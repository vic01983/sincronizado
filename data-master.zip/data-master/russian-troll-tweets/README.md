# 3 million Russian troll tweets

The data used in the FiveThirtyEight story [Why We’re Sharing 3 Million Russian Troll Tweets](https://fivethirtyeight.com/features/why-were-sharing-3-million-russian-troll-tweets) lives, with its documentation, in a [separate repository](https://github.com/fivethirtyeight/russian-troll-tweets).