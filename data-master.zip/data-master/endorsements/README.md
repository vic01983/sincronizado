---
files:
  - https://projects.fivethirtyeight.com/endorsements-2020-data/endorsements-2020.csv
---

# Endorsements

This file contains links to the data behind [The 2020 Endorsement Primary](https://projects.fivethirtyeight.com/2020-endorsements/democratic-primary/).

**Methodology:**

- [How Our Presidential Endorsement Tracker Works](https://fivethirtyeight.com/methodology/how-our-presidential-endorsement-tracker-works/)


**Related Posts:** 

- [We’re Tracking 2020 Presidential Endorsements. Here’s Why They Probably Still Matter](https://fivethirtyeight.com/features/were-tracking-2020-presidential-endorsements-heres-why-they-probably-still-matter/)
- [The Endorsement Primary
(2016s](https://projects.fivethirtyeight.com/2016-endorsement-primary/)



