# Obama Commutation

This folder contains data behind the story [Obama Granted Clemency Unlike Any Other President In History](https://fivethirtyeight.com/features/obama-granted-clemency-unlike-any-other-president-in-history/).

The data in `obama_commutations.csv` is copied from the Justice Department website. The python script parses it by looking at the first column to figure out what is contained in the second column.

Source: [Department of Justice](https://www.justice.gov/pardon/obama-commutations)
