# presidential-candidate-favorables-2019

This folder contains the data behind the story [The Democratic Presidential Candidates Are Becoming Less Popular](https://fivethirtyeight.com/features/the-democratic-presidential-candidates-are-becoming-less-popular/)

`favorability_polls_rv_2019.csv` contains polls that asked registered voters whether they had favorable or unfavorable opinion of the leading Democratic presidential primary candidates and President Trump. Polls range from Jan. 1, 2019 to Dec. 11, 2019.
