# Librarians

This folder contains data behind the story [Where Are America’s Librarians?](https://fivethirtyeight.com/features/where-are-americas-librarians/)
