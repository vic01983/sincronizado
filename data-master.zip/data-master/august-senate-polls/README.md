# August Senate Polls

This folder contains the data behind the story [How Much Trouble Is Ted Cruz Really In?
](https://fivethirtyeight.com/features/how-much-trouble-is-ted-cruz-really-in/)

`august_senate_polls.csv` contains every senate poll in our database from 1990 to 2016 that was conducted in the month of August along with the results of the election corresponding to each poll and the average error of each poll.