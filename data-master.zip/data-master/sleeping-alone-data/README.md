# Sleeping Alone

This folder contains data behind the story [Dear Mona, How Many Couples Sleep in Separate Beds?](https://fivethirtyeight.com/features/dear-mona-how-many-couples-sleep-in-separate-beds/)