# NBA Tattoos

This folder contains data behind the story [What Ethan Swan Learned From Tracking Every Tattoo in the NBA](https://fivethirtyeight.com/features/what-ethan-swan-learned-from-tracking-every-tattoo-in-the-nba/)