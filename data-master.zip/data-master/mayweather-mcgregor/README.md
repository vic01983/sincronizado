# Mayweather vs McGregor

This folder contains data behind the story [The Mayweather-McGregor Fight As Told Through Emojis](https://fivethirtyeight.com/?post_type=fte_features&p=161615).

`tweets.csv` contains 12,118 tweets that contain one or more emojis and match one or more of the following hashtags: #MayMac, #MayweatherMcGregor, #MayweatherVMcGregor, #MayweatherVsMcGregor, #McGregor and #Mayweather. Data was collected on August 27, 2017 between 12:05 a.m. and 1:15 a.m. EDT using the Twitter streaming API.