---
files:
  - https://docs.google.com/spreadsheets/d/e/2PACX-1vS15V8lYPUc_OH4OBss6d8NPGRnCH1lAlBBY4FYWcK6cm6iVM8dXE_4KMFOUybRe-cVvDg7ap46FPig/pub?gid=39569490&single=true&output=csv&/impeachment-polls.csv
  - https://projects.fivethirtyeight.com/impeachment-polls/impeachment_topline.csv
---

# Impeachment Polls

This file contains links to the data behind [Do Americans Support Impeaching Trump?](https://fivethirtyeight.com/features/do-americans-support-impeaching-president-trump/)
